package com.ganesh.restfulprovidersample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulProviderSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
