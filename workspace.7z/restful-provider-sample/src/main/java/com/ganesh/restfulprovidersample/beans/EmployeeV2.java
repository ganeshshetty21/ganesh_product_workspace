package com.ganesh.restfulprovidersample.beans;

public class EmployeeV2 {
	private Long id;
	private Name name;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}
}
