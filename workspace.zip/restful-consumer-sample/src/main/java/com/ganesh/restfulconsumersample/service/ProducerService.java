package com.ganesh.restfulconsumersample.service;

public interface ProducerService {

}
