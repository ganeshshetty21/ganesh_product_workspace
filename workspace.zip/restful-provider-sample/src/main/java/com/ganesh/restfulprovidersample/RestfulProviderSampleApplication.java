package com.ganesh.restfulprovidersample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulProviderSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulProviderSampleApplication.class, args);
	}

}
